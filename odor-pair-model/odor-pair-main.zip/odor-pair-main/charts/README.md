This is all the charts for the paper. One notebook per chart.
